<?php echo get_partial('term/format', array('resource' => $resource)) ?>
