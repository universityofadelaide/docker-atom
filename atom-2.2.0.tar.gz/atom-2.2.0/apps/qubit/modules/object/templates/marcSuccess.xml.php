<record xmlns="http://www.loc.gov/MARC21/slim"
 xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
 xsi:schemaLocation="http://www.loc.gov/MARC21/slim http://www.loc.gov/standards/marcxml/schema/MARC21slim.xsd" type="Bibliographic" id="ID001">
    <leader id="ID003">      0   22        4500</leader>
    <controlfield id="ID005" tag="001">controlfield0</controlfield>
    <datafield id="ID007" tag="010" ind1=" " ind2=" ">
        <subfield id="ID009" code="!">subfield0</subfield>
        <subfield id="ID011" code="!">subfield1</subfield>
        <subfield id="ID013" code="!">subfield2</subfield>
    </datafield>
</record>
