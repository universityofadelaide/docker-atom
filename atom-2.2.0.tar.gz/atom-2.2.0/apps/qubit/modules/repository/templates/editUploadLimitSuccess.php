<?php include_component('repository', 'uploadLimit', array('resource' => $resource, 'noedit' => true)) ?>
