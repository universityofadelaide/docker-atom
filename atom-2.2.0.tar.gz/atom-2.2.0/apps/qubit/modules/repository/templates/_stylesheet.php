<style type="text/css">
  html, body {
    background-image: none !important;
    background-color: <?php echo $backgroundColor ?> !important;
  }
</style>