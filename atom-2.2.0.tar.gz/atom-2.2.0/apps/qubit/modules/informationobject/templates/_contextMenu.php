<?php echo get_component('repository', 'logo') ?>

<?php echo get_component('informationobject', 'treeView') ?>

<?php // echo get_component('informationobject', 'creator', array('resource' => $resource)) ?>

<?php // echo get_component('digitalobject', 'imageflow', array('resource' => $resource)) ?>
